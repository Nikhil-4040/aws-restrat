first_string="hi"
second_string="nikhil"
third_string=first_string+second_string
print(third_string)

num="america"
print(type(num))

name=input("what is your name? ")
color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("{},you like a{} {}!".format(name,color,animal))

string1 = 'NIKHIL'
for i in string1:
    print(i)
