myFruitList = ["apple", "banana", "cherry"]
print(type(myFruitList))
print(myFruitList[0])
myFruitList.insert(2,"pineapple")
print(myFruitList)
myFruitList[3]="pomegranate"
print(myFruitList)

myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))
print(myFinalAnswerTuple[0])
print(myFinalAnswerTuple[2])

myFavoriteFruitDictionary = { "Akua" : "apple", "Saanvi" : "banana", "Paulo" : "pineapple"}
print(myFavoriteFruitDictionary)
print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["Saanvi"])
