import os
os.system("ls")

import subprocess
subprocess.run(["ls"])

import subprocess
subprocess.run(["ls","-l"])