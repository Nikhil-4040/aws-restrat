myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45"]
for i in myMixedTypeList:
    print("{} is a datatype of {}".format(i,type(i)))
    
    